
export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  prepTime: string;
  cookTime: string;
  servings: number;
  difficulty: 'Easy' | 'Intermediate' | 'Advanced';
  category: 'Appetizers' | 'Main Courses' | 'Desserts' | 'Drinks' | 'Vegetarian';
  tags: string[];
  ingredients: string[];
  instructions: string[];
  nutrition: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  image?: string;
}

export type AppView = 'home' | 'ai-kitchen' | 'meal-planner' | 'saved-recipes';
