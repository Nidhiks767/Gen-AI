
import React from 'react';
import { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
  onClick: (recipe: Recipe) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onClick }) => {
  return (
    <div 
      className="group bg-white rounded-2xl overflow-hidden border border-stone-200 hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col h-full"
      onClick={() => onClick(recipe)}
    >
      <div className="relative h-56 overflow-hidden">
        <img 
          src={recipe.image} 
          alt={recipe.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4 flex gap-2">
          {recipe.tags.slice(0, 2).map(tag => (
            <span key={tag} className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider text-stone-700">
              {tag}
            </span>
          ))}
        </div>
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center gap-4 mb-2 text-stone-500 text-xs font-medium">
          <span className="flex items-center gap-1">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {recipe.prepTime}
          </span>
          <span className="flex items-center gap-1">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            {recipe.difficulty}
          </span>
        </div>
        <h3 className="text-lg font-bold text-stone-900 group-hover:text-orange-600 transition-colors line-clamp-1 mb-2">
          {recipe.title}
        </h3>
        <p className="text-sm text-stone-600 line-clamp-2 mb-4 flex-grow">
          {recipe.description}
        </p>
        <div className="flex items-center justify-between pt-4 border-t border-stone-100 mt-auto">
          <div className="flex -space-x-2">
            {[1, 2, 3].map(i => (
              <img key={i} className="w-6 h-6 rounded-full border-2 border-white" src={`https://picsum.photos/32/32?random=${i}`} alt="user" />
            ))}
            <span className="text-[10px] text-stone-400 self-center ml-2">+12 cooked this</span>
          </div>
          <button className="text-orange-500 text-sm font-semibold hover:underline">View Recipe</button>
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;
