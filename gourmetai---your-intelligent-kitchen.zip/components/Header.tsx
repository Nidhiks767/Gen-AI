
import React from 'react';
import { AppView } from '../types';

interface HeaderProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'home', label: 'Recipes' },
    { id: 'ai-kitchen', label: 'AI Kitchen' },
    { id: 'meal-planner', label: 'Planner' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => setView('home')}
          >
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-xl">
              G
            </div>
            <span className="text-xl font-bold text-stone-900 hidden sm:block">GourmetAI</span>
          </div>

          <nav className="flex items-center gap-1 sm:gap-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id as AppView)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === item.id 
                    ? 'bg-orange-100 text-orange-600' 
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center bg-stone-100 rounded-full px-4 py-2 w-64 border border-stone-200 focus-within:border-orange-500 focus-within:bg-white transition-all">
            <svg className="w-4 h-4 text-stone-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input 
              type="text" 
              placeholder="Search recipes..." 
              className="bg-transparent border-none focus:ring-0 text-sm w-full outline-none"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
