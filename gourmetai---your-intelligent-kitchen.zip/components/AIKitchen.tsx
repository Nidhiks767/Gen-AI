
import React, { useState, useRef, useEffect } from 'react';
import { generateRecipe, generateRecipeImage } from '../services/geminiService';
import { Recipe } from '../types';

interface AIKitchenProps {
  onRecipeGenerated: (recipe: Recipe) => void;
}

const AIKitchen: React.FC<AIKitchenProps> = ({ onRecipeGenerated }) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    setError(null);
    setLoadingStep('Analyzing your request...');

    try {
      setLoadingStep('Crafting the perfect recipe...');
      const recipe = await generateRecipe(prompt);
      
      if (recipe) {
        setLoadingStep('Capturing a visual representation...');
        const customImage = await generateRecipeImage(recipe.title);
        if (customImage) {
          recipe.image = customImage;
        }
        onRecipeGenerated(recipe);
        setPrompt('');
      } else {
        setError("I couldn't generate a recipe for that. Try something like 'Vegan lasagna' or 'Quick healthy snacks'.");
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold text-stone-900 mb-4">The AI Kitchen</h1>
        <p className="text-stone-600 text-lg max-w-2xl mx-auto">
          Describe what you have in your fridge or a specific craving, and our AI chef will design a custom recipe just for you.
        </p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl p-8 border border-stone-100">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Try 'A 30-minute Mediterranean salmon dinner for two using spinach and cherry tomatoes'..."
              className="w-full h-32 p-6 bg-stone-50 rounded-2xl border border-stone-200 focus:border-orange-500 focus:ring-4 focus:ring-orange-100 transition-all outline-none text-lg resize-none"
              disabled={isLoading}
            />
            <div className="absolute bottom-4 right-4 text-stone-400 text-sm">
              Powered by Gemini 3 Flash
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="w-full py-4 bg-orange-600 hover:bg-orange-700 disabled:bg-stone-300 text-white rounded-2xl font-bold text-lg shadow-lg shadow-orange-200 transition-all transform hover:-translate-y-1 active:scale-[0.98] flex items-center justify-center gap-3"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-6 w-6 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {loadingStep}
              </>
            ) : (
              <>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Generate Magic Recipe
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm flex items-center gap-3">
            <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {error}
          </div>
        )}
      </div>

      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { icon: '🥗', title: 'Healthy & Fresh', desc: 'Prioritizing whole ingredients and nutritional balance.' },
          { icon: '⏱️', title: 'Time Flexible', desc: 'Specify how much time you have, and we adjust.' },
          { icon: '🏠', title: 'Pantry Ready', desc: 'Mention what you have on hand to reduce food waste.' }
        ].map((feat, idx) => (
          <div key={idx} className="bg-stone-100/50 p-6 rounded-2xl border border-stone-200/50">
            <div className="text-3xl mb-3">{feat.icon}</div>
            <h3 className="font-bold text-stone-900 mb-2">{feat.title}</h3>
            <p className="text-sm text-stone-600">{feat.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIKitchen;
