
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import RecipeCard from './components/RecipeCard';
import AIKitchen from './components/AIKitchen';
import { Recipe, AppView } from './types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const MOCK_RECIPES: Recipe[] = [
  {
    id: '1',
    title: 'Avocado Toast with Poached Egg',
    description: 'A classic breakfast staple elevated with chili flakes and microgreens.',
    image: 'https://picsum.photos/seed/avotoast/800/600',
    prepTime: '10 min',
    cookTime: '5 min',
    servings: 1,
    difficulty: 'Easy',
    category: 'Vegetarian',
    tags: ['Breakfast', 'Quick', 'Healthy'],
    ingredients: ['2 slices sourdough', '1 ripe avocado', '2 large eggs', 'Chili flakes', 'Lemon juice'],
    instructions: ['Toast the bread until golden.', 'Mash avocado with lemon juice and salt.', 'Poach eggs in simmering water.', 'Assemble and top with chili flakes.'],
    nutrition: { calories: 450, protein: 18, carbs: 32, fat: 28 }
  },
  {
    id: '2',
    title: 'Miso Glazed Salmon',
    description: 'Umami-rich salmon served with steamed bok choy and jasmine rice.',
    image: 'https://picsum.photos/seed/salmon/800/600',
    prepTime: '15 min',
    cookTime: '12 min',
    servings: 2,
    difficulty: 'Intermediate',
    category: 'Main Courses',
    tags: ['Dinner', 'Seafood', 'High-Protein'],
    ingredients: ['2 salmon fillets', '3 tbsp white miso', '2 tbsp mirin', '1 tbsp gaminger', 'Bok choy'],
    instructions: ['Whisk miso, mirin, and ginger.', 'Marinate salmon for 10 mins.', 'Bake at 400°F for 10-12 mins.', 'Serve with steamed bok choy.'],
    nutrition: { calories: 520, protein: 42, carbs: 12, fat: 34 }
  },
  {
    id: '3',
    title: 'Berry Smoothie Bowl',
    description: 'A refreshing and nutrient-dense bowl topped with granola and fresh fruits.',
    image: 'https://picsum.photos/seed/smoothie/800/600',
    prepTime: '5 min',
    cookTime: '0 min',
    servings: 1,
    difficulty: 'Easy',
    category: 'Drinks',
    tags: ['Breakfast', 'Vegan', 'Refresh'],
    ingredients: ['1 cup frozen berries', '1 banana', '1/2 cup almond milk', 'Granola', 'Chia seeds'],
    instructions: ['Blend berries, banana, and milk until smooth.', 'Pour into a bowl.', 'Top with granola, seeds, and extra berries.'],
    nutrition: { calories: 310, protein: 8, carbs: 54, fat: 9 }
  },
  {
    id: '4',
    title: 'Crispy Garlic Bruschetta',
    description: 'Traditional Italian appetizer with toasted bread and fresh tomato topping.',
    image: 'https://picsum.photos/seed/bruschetta/800/600',
    prepTime: '10 min',
    cookTime: '5 min',
    servings: 4,
    difficulty: 'Easy',
    category: 'Appetizers',
    tags: ['Italian', 'Party', 'Vegetarian'],
    ingredients: ['Baguette', 'Garlic cloves', 'Tomatoes', 'Basil', 'Olive oil'],
    instructions: ['Toast sliced baguette.', 'Rub with garlic.', 'Top with diced tomatoes and basil.', 'Drizzle with olive oil.'],
    nutrition: { calories: 150, protein: 4, carbs: 22, fat: 6 }
  },
  {
    id: '5',
    title: 'Double Chocolate Lava Cake',
    description: 'Decadent warm chocolate cake with a molten center.',
    image: 'https://picsum.photos/seed/lavacake/800/600',
    prepTime: '15 min',
    cookTime: '12 min',
    servings: 2,
    difficulty: 'Intermediate',
    category: 'Desserts',
    tags: ['Sweet', 'Indulgent'],
    ingredients: ['Dark chocolate', 'Butter', 'Eggs', 'Sugar', 'Flour'],
    instructions: ['Melt chocolate and butter.', 'Beat eggs and sugar.', 'Fold in flour and chocolate.', 'Bake until edges are set but center is soft.'],
    nutrition: { calories: 480, protein: 6, carbs: 42, fat: 32 }
  }
];

const CATEGORIES = ['All', 'Appetizers', 'Main Courses', 'Desserts', 'Drinks', 'Vegetarian'] as const;

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('home');
  const [recipes, setRecipes] = useState<Recipe[]>(MOCK_RECIPES);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const filteredRecipes = activeCategory === 'All' 
    ? recipes 
    : recipes.filter(r => r.category === activeCategory);

  const handleRecipeGenerated = (newRecipe: Recipe) => {
    setRecipes([newRecipe, ...recipes]);
    setSelectedRecipe(newRecipe);
    setView('home');
    setActiveCategory('All');
  };

  const renderNutritionChart = (nutrition: Recipe['nutrition']) => {
    const data = [
      { name: 'Protein', value: nutrition.protein, color: '#f97316' },
      { name: 'Carbs', value: nutrition.carbs, color: '#3b82f6' },
      { name: 'Fat', value: nutrition.fat, color: '#10b981' },
    ];

    return (
      <div className="h-48 w-full mt-4">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical">
            <XAxis type="number" hide />
            <YAxis dataKey="name" type="category" width={70} tick={{ fontSize: 12 }} />
            <Tooltip />
            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="text-center mt-2 text-lg font-bold text-stone-900">
          {nutrition.calories} <span className="text-sm font-normal text-stone-500">kcal</span>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header currentView={view} setView={setView} />

      <main className="flex-grow">
        {view === 'home' && (
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6">
              <div>
                <h2 className="text-3xl font-extrabold text-stone-900">Discover Recipes</h2>
                <p className="text-stone-500">Explore our curated collection of amazing dishes.</p>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                      activeCategory === cat
                        ? 'bg-orange-600 text-white shadow-lg shadow-orange-100'
                        : 'bg-white text-stone-600 border border-stone-200 hover:border-orange-300'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {filteredRecipes.length > 0 ? (
              <div className="recipe-grid">
                {filteredRecipes.map((recipe) => (
                  <RecipeCard 
                    key={recipe.id} 
                    recipe={recipe} 
                    onClick={setSelectedRecipe} 
                  />
                ))}
              </div>
            ) : (
              <div className="py-20 text-center">
                <div className="text-4xl mb-4">🍳</div>
                <h3 className="text-xl font-bold text-stone-900">No recipes found</h3>
                <p className="text-stone-500">Try selecting a different category or generate a new one!</p>
              </div>
            )}
          </div>
        )}

        {view === 'ai-kitchen' && (
          <AIKitchen onRecipeGenerated={handleRecipeGenerated} />
        )}

        {view === 'meal-planner' && (
          <div className="max-w-7xl mx-auto px-4 py-12 flex flex-col items-center justify-center text-center">
            <div className="w-24 h-24 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center text-4xl mb-6">📅</div>
            <h2 className="text-3xl font-bold text-stone-900 mb-2">Weekly Meal Planner</h2>
            <p className="text-stone-600 max-w-md mb-8">Automatically generate a shopping list and schedule your meals for the week. Coming soon!</p>
            <button className="px-8 py-3 bg-stone-900 text-white rounded-xl font-bold hover:bg-stone-800 transition-colors">
              Notify Me
            </button>
          </div>
        )}
      </main>

      {/* Recipe Modal */}
      {selectedRecipe && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm" onClick={() => setSelectedRecipe(null)} />
          <div className="relative bg-white w-full max-w-5xl max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
            <button 
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-stone-900 hover:bg-white shadow-md"
              onClick={() => setSelectedRecipe(null)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="md:w-1/2 relative h-64 md:h-auto overflow-hidden">
              <img 
                src={selectedRecipe.image} 
                alt={selectedRecipe.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent md:hidden" />
              <div className="absolute bottom-6 left-6 text-white md:hidden">
                <h2 className="text-2xl font-bold">{selectedRecipe.title}</h2>
              </div>
            </div>

            <div className="md:w-1/2 p-6 md:p-10 overflow-y-auto bg-white">
              <div className="hidden md:block mb-6">
                <div className="flex gap-2 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-orange-600 bg-orange-50 px-2 py-1 rounded">
                    {selectedRecipe.category}
                  </span>
                  {selectedRecipe.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold uppercase tracking-widest text-stone-500 bg-stone-100 px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
                <h2 className="text-3xl font-black text-stone-900">{selectedRecipe.title}</h2>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-8 text-center p-4 bg-stone-50 rounded-2xl">
                <div>
                  <div className="text-xs text-stone-400 font-bold uppercase">Time</div>
                  <div className="font-bold text-stone-900">{selectedRecipe.cookTime}</div>
                </div>
                <div>
                  <div className="text-xs text-stone-400 font-bold uppercase">Serves</div>
                  <div className="font-bold text-stone-900">{selectedRecipe.servings}</div>
                </div>
                <div>
                  <div className="text-xs text-stone-400 font-bold uppercase">Difficulty</div>
                  <div className="font-bold text-stone-900">{selectedRecipe.difficulty}</div>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-stone-900 mb-4 border-b pb-2">Ingredients</h3>
                <ul className="space-y-2">
                  {selectedRecipe.ingredients.map((ing, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-stone-700 text-sm">
                      <div className="w-5 h-5 border-2 border-orange-200 rounded flex-shrink-0 mt-0.5" />
                      {ing}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-stone-900 mb-4 border-b pb-2">Method</h3>
                <ol className="space-y-6">
                  {selectedRecipe.instructions.map((step, idx) => (
                    <li key={idx} className="flex gap-4">
                      <span className="flex-shrink-0 w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold">
                        {idx + 1}
                      </span>
                      <p className="text-stone-700 text-sm leading-relaxed">{step}</p>
                    </li>
                  ))}
                </ol>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-stone-900 mb-4 border-b pb-2">Nutrition Facts</h3>
                {renderNutritionChart(selectedRecipe.nutrition)}
              </div>

              <div className="flex gap-4 pt-4 sticky bottom-0 bg-white">
                <button className="flex-grow py-4 bg-orange-600 text-white rounded-xl font-bold shadow-lg shadow-orange-100">
                  Save to My Recipes
                </button>
                <button className="p-4 border border-stone-200 rounded-xl hover:bg-stone-50">
                  <svg className="w-6 h-6 text-stone-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6a3 3 0 100-2.684m0 2.684l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="bg-stone-900 text-stone-400 py-12">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white font-bold text-lg">G</div>
              <span className="text-xl font-bold text-white">GourmetAI</span>
            </div>
            <p className="max-w-xs mb-6 text-sm leading-relaxed">
              Empowering home cooks with intelligent tools. Discover, create, and plan your perfect culinary journey with the help of advanced AI.
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 uppercase text-xs tracking-widest">Platform</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Recipes</a></li>
              <li><a href="#" className="hover:text-white transition-colors">AI Kitchen</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Meal Planner</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 uppercase text-xs tracking-widest">Connect</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Twitter</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Support</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-stone-800 text-xs flex justify-between">
          <span>&copy; 2024 GourmetAI. Powered by Gemini.</span>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
