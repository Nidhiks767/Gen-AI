
import { GoogleGenAI, Type } from "@google/genai";
import { Recipe } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateRecipe = async (prompt: string): Promise<Recipe | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Create a detailed recipe based on: ${prompt}. Return the output in strict JSON format. Ensure the category is one of: 'Appetizers', 'Main Courses', 'Desserts', 'Drinks', 'Vegetarian'.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            prepTime: { type: Type.STRING },
            cookTime: { type: Type.STRING },
            servings: { type: Type.NUMBER },
            difficulty: { type: Type.STRING },
            category: { 
              type: Type.STRING,
              description: "Must be one of: 'Appetizers', 'Main Courses', 'Desserts', 'Drinks', 'Vegetarian'"
            },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            instructions: { type: Type.ARRAY, items: { type: Type.STRING } },
            nutrition: {
              type: Type.OBJECT,
              properties: {
                calories: { type: Type.NUMBER },
                protein: { type: Type.NUMBER },
                carbs: { type: Type.NUMBER },
                fat: { type: Type.NUMBER }
              },
              required: ["calories", "protein", "carbs", "fat"]
            }
          },
          required: ["title", "description", "prepTime", "cookTime", "servings", "difficulty", "category", "ingredients", "instructions", "nutrition"]
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    return {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      image: `https://picsum.photos/seed/${data.title}/800/600`
    };
  } catch (error) {
    console.error("Error generating recipe:", error);
    return null;
  }
};

export const generateRecipeImage = async (title: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `A high-quality, professional food photography shot of ${title}, plated beautifully, warm lighting, macro shot.` }]
      },
      config: {
        imageConfig: { aspectRatio: "16:9" }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    return null;
  }
};

export const chatWithChef = async (history: { role: 'user' | 'model'; parts: { text: string }[] }[], message: string) => {
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: 'You are an expert Michelin-star chef. You provide cooking advice, ingredient substitutions, and culinary techniques. Keep your answers concise, helpful, and enthusiastic.',
    },
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};
